# IO.Swagger.Model.OutputParameters
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PurchasePrice** | **decimal?** | numeric | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

