# IO.Swagger.Model.StartBatchExecutionResponse
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**BatchExecutionId** | **string** | Id of the asynchronous execution. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

