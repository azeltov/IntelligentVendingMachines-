# IO.Swagger.Api.ApiPredictPurchasePriceApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ApiPredictPurchasePrice**](ApiPredictPurchasePriceApi.md#apipredictpurchaseprice) | **POST** /api/apiPredictPurchasePrice/1.0 | 
[**CancelAndDeleteBatchExecution**](ApiPredictPurchasePriceApi.md#cancelanddeletebatchexecution) | **DELETE** /api/apiPredictPurchasePrice/1.0/batch/{executionId} | Cancels and deletes all batch executions for apiPredictPurchasePrice.
[**GetBatchExecutionFile**](ApiPredictPurchasePriceApi.md#getbatchexecutionfile) | **GET** /api/apiPredictPurchasePrice/1.0/batch/{executionId}/{index}/files/{fileName} | Gets a specific file from an execution in apiPredictPurchasePrice.
[**GetBatchExecutionFiles**](ApiPredictPurchasePriceApi.md#getbatchexecutionfiles) | **GET** /api/apiPredictPurchasePrice/1.0/batch/{executionId}/{index}/files | Gets all files from an individual execution in apiPredictPurchasePrice.
[**GetBatchExecutionStatus**](ApiPredictPurchasePriceApi.md#getbatchexecutionstatus) | **GET** /api/apiPredictPurchasePrice/1.0/batch/{executionId} | Gets all batch executions for apiPredictPurchasePrice.
[**GetBatchExecutions**](ApiPredictPurchasePriceApi.md#getbatchexecutions) | **GET** /api/apiPredictPurchasePrice/1.0/batch | Gets all batch executions for apiPredictPurchasePrice.
[**StartBatchExecution**](ApiPredictPurchasePriceApi.md#startbatchexecution) | **POST** /api/apiPredictPurchasePrice/1.0/batch | 


<a name="apipredictpurchaseprice"></a>
# **ApiPredictPurchasePrice**
> WebServiceResult ApiPredictPurchasePrice (InputParameters webServiceParameters)



Consume the apiPredictPurchasePrice web service.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ApiPredictPurchasePriceExample
    {
        public void main()
        {
            // Configure API key authorization: Bearer
            Configuration.Default.ApiKey.Add("Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.ApiKeyPrefix.Add("Authorization", "Bearer");

            var apiInstance = new ApiPredictPurchasePriceApi();
            var webServiceParameters = new InputParameters(); // InputParameters | Input parameters to the web service.

            try
            {
                WebServiceResult result = apiInstance.ApiPredictPurchasePrice(webServiceParameters);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ApiPredictPurchasePriceApi.ApiPredictPurchasePrice: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **webServiceParameters** | [**InputParameters**](InputParameters.md)| Input parameters to the web service. | 

### Return type

[**WebServiceResult**](WebServiceResult.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="cancelanddeletebatchexecution"></a>
# **CancelAndDeleteBatchExecution**
> List<string> CancelAndDeleteBatchExecution (string executionId)

Cancels and deletes all batch executions for apiPredictPurchasePrice.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class CancelAndDeleteBatchExecutionExample
    {
        public void main()
        {
            // Configure API key authorization: Bearer
            Configuration.Default.ApiKey.Add("Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.ApiKeyPrefix.Add("Authorization", "Bearer");

            var apiInstance = new ApiPredictPurchasePriceApi();
            var executionId = executionId_example;  // string | Execution id of the execution.

            try
            {
                // Cancels and deletes all batch executions for apiPredictPurchasePrice.
                List&lt;string&gt; result = apiInstance.CancelAndDeleteBatchExecution(executionId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ApiPredictPurchasePriceApi.CancelAndDeleteBatchExecution: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **executionId** | **string**| Execution id of the execution. | 

### Return type

**List<string>**

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getbatchexecutionfile"></a>
# **GetBatchExecutionFile**
> System.IO.Stream GetBatchExecutionFile (string executionId, int? index, string fileName)

Gets a specific file from an execution in apiPredictPurchasePrice.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetBatchExecutionFileExample
    {
        public void main()
        {
            // Configure API key authorization: Bearer
            Configuration.Default.ApiKey.Add("Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.ApiKeyPrefix.Add("Authorization", "Bearer");

            var apiInstance = new ApiPredictPurchasePriceApi();
            var executionId = executionId_example;  // string | Execution id of the execution
            var index = 56;  // int? | Index of the execution in the batch.
            var fileName = fileName_example;  // string | Name of the file to be returned.

            try
            {
                // Gets a specific file from an execution in apiPredictPurchasePrice.
                System.IO.Stream result = apiInstance.GetBatchExecutionFile(executionId, index, fileName);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ApiPredictPurchasePriceApi.GetBatchExecutionFile: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **executionId** | **string**| Execution id of the execution | 
 **index** | **int?**| Index of the execution in the batch. | 
 **fileName** | **string**| Name of the file to be returned. | 

### Return type

**System.IO.Stream**

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getbatchexecutionfiles"></a>
# **GetBatchExecutionFiles**
> List<string> GetBatchExecutionFiles (string executionId, int? index)

Gets all files from an individual execution in apiPredictPurchasePrice.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetBatchExecutionFilesExample
    {
        public void main()
        {
            // Configure API key authorization: Bearer
            Configuration.Default.ApiKey.Add("Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.ApiKeyPrefix.Add("Authorization", "Bearer");

            var apiInstance = new ApiPredictPurchasePriceApi();
            var executionId = executionId_example;  // string | Execution id of the execution
            var index = 56;  // int? | Index of the execution in the batch.

            try
            {
                // Gets all files from an individual execution in apiPredictPurchasePrice.
                List&lt;string&gt; result = apiInstance.GetBatchExecutionFiles(executionId, index);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ApiPredictPurchasePriceApi.GetBatchExecutionFiles: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **executionId** | **string**| Execution id of the execution | 
 **index** | **int?**| Index of the execution in the batch. | 

### Return type

**List<string>**

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getbatchexecutionstatus"></a>
# **GetBatchExecutionStatus**
> BatchWebServiceResult GetBatchExecutionStatus (string executionId, bool? showPartialResults = null)

Gets all batch executions for apiPredictPurchasePrice.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetBatchExecutionStatusExample
    {
        public void main()
        {
            // Configure API key authorization: Bearer
            Configuration.Default.ApiKey.Add("Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.ApiKeyPrefix.Add("Authorization", "Bearer");

            var apiInstance = new ApiPredictPurchasePriceApi();
            var executionId = executionId_example;  // string | Execution id of the execution
            var showPartialResults = true;  // bool? | Returns the already processed results of the batch execution even if it hasn't been fully completed. (optional) 

            try
            {
                // Gets all batch executions for apiPredictPurchasePrice.
                BatchWebServiceResult result = apiInstance.GetBatchExecutionStatus(executionId, showPartialResults);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ApiPredictPurchasePriceApi.GetBatchExecutionStatus: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **executionId** | **string**| Execution id of the execution | 
 **showPartialResults** | **bool?**| Returns the already processed results of the batch execution even if it hasn&#39;t been fully completed. | [optional] 

### Return type

[**BatchWebServiceResult**](BatchWebServiceResult.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getbatchexecutions"></a>
# **GetBatchExecutions**
> List<string> GetBatchExecutions ()

Gets all batch executions for apiPredictPurchasePrice.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetBatchExecutionsExample
    {
        public void main()
        {
            // Configure API key authorization: Bearer
            Configuration.Default.ApiKey.Add("Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.ApiKeyPrefix.Add("Authorization", "Bearer");

            var apiInstance = new ApiPredictPurchasePriceApi();

            try
            {
                // Gets all batch executions for apiPredictPurchasePrice.
                List&lt;string&gt; result = apiInstance.GetBatchExecutions();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ApiPredictPurchasePriceApi.GetBatchExecutions: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

**List<string>**

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="startbatchexecution"></a>
# **StartBatchExecution**
> StartBatchExecutionResponse StartBatchExecution (List<InputParameters> batchWebServiceParameters, int? parallelCount = null)



Consume the apiPredictPurchasePrice web service asynchronously.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class StartBatchExecutionExample
    {
        public void main()
        {
            // Configure API key authorization: Bearer
            Configuration.Default.ApiKey.Add("Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.ApiKeyPrefix.Add("Authorization", "Bearer");

            var apiInstance = new ApiPredictPurchasePriceApi();
            var batchWebServiceParameters = new List<InputParameters>(); // List<InputParameters> | Input parameters to the web service.
            var parallelCount = 56;  // int? | Number of threads used to process entries in the batch. Default value is 10. Please make sure not to use too high of a number because it might negatively impact performance. (optional) 

            try
            {
                StartBatchExecutionResponse result = apiInstance.StartBatchExecution(batchWebServiceParameters, parallelCount);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ApiPredictPurchasePriceApi.StartBatchExecution: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **batchWebServiceParameters** | [**List&lt;InputParameters&gt;**](InputParameters.md)| Input parameters to the web service. | 
 **parallelCount** | **int?**| Number of threads used to process entries in the batch. Default value is 10. Please make sure not to use too high of a number because it might negatively impact performance. | [optional] 

### Return type

[**StartBatchExecutionResponse**](StartBatchExecutionResponse.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

