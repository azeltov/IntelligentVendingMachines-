# IO.Swagger.Model.AccessTokenResponse
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TokenType** | **string** |  | [optional] 
**AccessToken** | **string** |  | [optional] 
**ExpiresOn** | **string** |  | [optional] 
**RefreshToken** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

